"""
engine.py
=========
Event-driven backtesting engine.

Fixes vs. original
-------------------
Bug #3 / #5 : Max drawdown was inverted AND used arithmetic cumsum.
              Fixed to use geometric (1+r).cumprod() and correct formula:
              MDD = min(NAV / peak_NAV - 1)

Bug #4      : Sharpe annualisation used flat 252-day multiplier on
              event-based returns, which is only correct for daily returns.
              Fixed: annualise by the *observed* number of signals per year.

Bug #11     : Chained .loc on MultiIndex replaced with pd.IndexSlice,
              wrapped in a proper try/except.
"""
from __future__ import annotations

import logging
from datetime import timedelta
from typing import Dict

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class Backtester:
    """
    Simulate next-day execution of news-driven signals.

    Parameters
    ----------
    price_data : pd.DataFrame
        Must contain columns: date (or DatetimeIndex), ticker, return.
        'return' is the one-day simple return for that ticker on that date.
    """

    def __init__(self, price_data: pd.DataFrame) -> None:
        # Normalise the index for safe MultiIndex lookup
        price_data = price_data.copy()
        price_data["date"] = pd.to_datetime(price_data["date"]).dt.normalize()
        self._prices = price_data.set_index(["date", "ticker"])

    # ------------------------------------------------------------------
    # Backtest execution
    # ------------------------------------------------------------------

    def run_backtest(self, signals: pd.DataFrame) -> pd.DataFrame:
        """
        Walk through signals in chronological order and look up next-day returns.

        Parameters
        ----------
        signals : pd.DataFrame
            Output of TradingStrategy.generate_signals() filtered to LONG/SHORT.

        Returns
        -------
        pd.DataFrame with columns:
            timestamp, ticker, headline, sentiment, action, trade_return
        """
        results = []

        for _, row in signals.sort_values("timestamp").iterrows():
            execution_date = (
                pd.Timestamp(row["timestamp"].date()) + timedelta(days=1)
            )

            # Bug #11 fix: safe MultiIndex lookup with pd.IndexSlice
            try:
                idx = pd.IndexSlice[execution_date, row["ticker"]]
                price_row = self._prices.loc[idx]
                raw_return = float(price_row["return"])
            except KeyError:
                logger.warning(
                    "No price data for %s on %s — skipping",
                    row["ticker"], execution_date.date(),
                )
                continue

            # LONG profits when return is positive; SHORT profits when negative
            trade_return = (
                raw_return if row["action"] == "LONG" else -raw_return
            )

            results.append(
                {
                    "timestamp":    row["timestamp"],
                    "ticker":       row["ticker"],
                    "headline":     row["headline"],
                    "sentiment":    row["sentiment"],
                    "action":       row["action"],
                    "trade_return": trade_return,
                }
            )

        return pd.DataFrame(results).dropna(subset=["trade_return"])

    # ------------------------------------------------------------------
    # Performance metrics
    # ------------------------------------------------------------------

    @staticmethod
    def calculate_metrics(results: pd.DataFrame) -> Dict[str, float]:
        """
        Compute standard performance metrics.

        Bug #3 fix  : max_drawdown uses geometric NAV and correct sign.
        Bug #4 fix  : Sharpe annualised by actual signal frequency, not 252.
        Bug #5 fix  : NAV computed via (1+r).cumprod() not cumsum().

        Parameters
        ----------
        results : pd.DataFrame — output of run_backtest()

        Returns
        -------
        dict with: sharpe_ratio, max_drawdown, total_return, hit_rate,
                   n_trades, avg_trade_return
        """
        if results.empty:
            return {}

        returns = results.set_index("timestamp")["trade_return"].sort_index()

        # ── Total return (geometric) ──────────────────────────────────
        total_return = float((1 + returns).prod() - 1)

        # ── NAV series for drawdown ───────────────────────────────────
        # Bug #5 fix: geometric compounding
        nav = (1 + returns).cumprod()

        # ── Max drawdown ──────────────────────────────────────────────
        # Bug #3 fix: peak − current, take the deepest trough (most negative)
        peak = nav.expanding().max()
        drawdowns = nav / peak - 1
        max_drawdown = float(drawdowns.min())   # ≤ 0

        # ── Sharpe ratio ──────────────────────────────────────────────
        # Bug #4 fix: annualise by observed signals-per-year, not 252
        if len(returns) > 1 and returns.std() > 0:
            date_range_years = (
                (returns.index[-1] - returns.index[0]).days / 365.25
            )
            signals_per_year = (
                len(returns) / max(date_range_years, 1 / 252)
            )
            sharpe = (
                returns.mean() / returns.std() * np.sqrt(signals_per_year)
            )
        else:
            sharpe = np.nan

        # ── Hit rate ─────────────────────────────────────────────────
        hit_rate = float((returns > 0).mean())

        return {
            "sharpe_ratio":      round(float(sharpe), 4),
            "max_drawdown":      round(max_drawdown, 4),      # negative number
            "total_return":      round(total_return, 4),
            "hit_rate":          round(hit_rate, 4),
            "n_trades":          len(returns),
            "avg_trade_return":  round(float(returns.mean()), 6),
        }
