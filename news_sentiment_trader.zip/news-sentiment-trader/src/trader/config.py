"""
config.py
=========
All configuration loaded from environment variables.
Never import API keys directly — use this module everywhere.

Usage:
    from trader.config import settings
    client = requests.Session()
    client.headers["Authorization"] = f"Bearer {settings.factset_api_key}"
"""
from __future__ import annotations

import os
from dataclasses import dataclass


def _require(key: str) -> str:
    """Read an env var or raise a clear error if missing."""
    val = os.environ.get(key, "").strip()
    if not val:
        raise EnvironmentError(
            f"Required environment variable '{key}' is not set. "
            "Copy .env.example → .env and fill in your credentials, "
            "then run: export $(cat .env | xargs)"
        )
    return val


def _optional(key: str, default: str = "") -> str:
    return os.environ.get(key, default).strip()


@dataclass(frozen=True)
class Settings:
    # FactSet
    factset_api_key:  str
    factset_base_url: str

    # DeepSeek
    deepseek_api_key:  str
    deepseek_base_url: str

    # Rate limits
    factset_calls_per_second: int = 10   # 10 req/s → 100 ms minimum interval
    deepseek_tokens_per_minute: int = 90_000  # conservative tier-1 default


def load_settings() -> Settings:
    """
    Load all settings from the environment.

    Call this once at startup; pass the returned Settings object
    down to clients rather than re-reading the environment everywhere.
    """
    # Try to load .env if python-dotenv is available
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass  # prod environments inject vars directly; dotenv is optional

    return Settings(
        factset_api_key=_require("FACTSET_API_KEY"),
        factset_base_url=_optional(
            "FACTSET_BASE_URL", "https://api.factset.com/rtnews"
        ),
        deepseek_api_key=_require("DEEPSEEK_API_KEY"),
        deepseek_base_url=_optional(
            "DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1/chat/completions"
        ),
    )
