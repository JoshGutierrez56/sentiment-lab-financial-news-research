"""
factset.py
==========
FactSet RTNews API client.

Fixes vs. original
-------------------
- API key loaded from Settings (no hardcoded secrets)
- Optional[datetime] sentinel instead of datetime.min
- Exponential-backoff retry decorator (bug #7)
- Rate limiting uses time.monotonic() for precision
- Returns typed, validated DataFrame
"""
from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import List, Optional

import pandas as pd
import requests
from requests.adapters import HTTPAdapter, Retry

from trader.config import Settings

logger = logging.getLogger(__name__)


def _retry_session(total: int = 3, backoff: float = 0.5) -> requests.Session:
    """
    Build a requests.Session with automatic exponential-backoff retry.

    Retries on: 429 (rate limit), 500, 502, 503, 504.
    Bug #7 fix: the original made a single bare request with no retry.
    """
    session = requests.Session()
    retry = Retry(
        total=total,
        backoff_factor=backoff,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


class FactSetClient:
    """
    FactSet RTNews API client with rate limiting and error handling.

    Parameters
    ----------
    settings : Settings
        Application settings loaded from environment variables.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._session  = _retry_session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {settings.factset_api_key}",
                "Accept": "application/json",
            }
        )
        # Bug #9 fix: use Optional[float] instead of datetime.min
        self._last_call_mono: Optional[float] = None
        self._min_interval = 1.0 / settings.factset_calls_per_second  # seconds

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def get_historical_news(
        self,
        ticker: str,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """
        Retrieve news headlines for a single ticker.

        Parameters
        ----------
        ticker     : FactSet entity ticker (e.g. "AAPL-US")
        start_date : ISO date string "YYYY-MM-DD"
        end_date   : ISO date string "YYYY-MM-DD"

        Returns
        -------
        pd.DataFrame with columns: timestamp (tz-aware ET), ticker, headline
        Empty DataFrame on any error.
        """
        self._rate_limit()

        params = {
            "symbols":   ticker,
            "startDate": start_date,
            "endDate":   end_date,
            "fields":    "headline,publicationTime",
        }

        try:
            response = self._session.get(
                f"{self._settings.factset_base_url}/historical",
                params=params,
                timeout=30,
            )
            response.raise_for_status()
        except requests.HTTPError as exc:
            logger.error("FactSet HTTP error for %s: %s", ticker, exc)
            return pd.DataFrame()
        except requests.RequestException as exc:
            logger.error("FactSet request failed for %s: %s", ticker, exc)
            return pd.DataFrame()

        data = response.json().get("data", [])
        if not data:
            logger.warning("No news returned for %s (%s – %s)", ticker, start_date, end_date)
            return pd.DataFrame()

        rows = []
        for item in data:
            try:
                rows.append(
                    {
                        "timestamp": (
                            pd.to_datetime(item["publicationTime"])
                            .tz_convert("America/New_York")
                        ),
                        "ticker":   ticker,
                        "headline": item["headline"].strip(),
                    }
                )
            except (KeyError, TypeError, ValueError) as exc:
                logger.warning("Skipping malformed news item: %s", exc)

        return pd.DataFrame(rows)

    def get_bulk_news(
        self,
        tickers: List[str],
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """
        Fetch news for multiple tickers, concatenate, and sort by timestamp.
        """
        frames = [
            self.get_historical_news(t, start_date, end_date)
            for t in tickers
        ]
        non_empty = [f for f in frames if not f.empty]
        if not non_empty:
            return pd.DataFrame(columns=["timestamp", "ticker", "headline"])
        return (
            pd.concat(non_empty, ignore_index=True)
            .sort_values("timestamp")
            .reset_index(drop=True)
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _rate_limit(self) -> None:
        """Block until the minimum inter-call interval has elapsed."""
        if self._last_call_mono is not None:
            elapsed = time.monotonic() - self._last_call_mono
            wait    = self._min_interval - elapsed
            if wait > 0:
                time.sleep(wait)
        self._last_call_mono = time.monotonic()
