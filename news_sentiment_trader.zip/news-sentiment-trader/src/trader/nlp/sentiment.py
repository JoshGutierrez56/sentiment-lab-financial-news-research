"""
sentiment.py
============
DeepSeek LLM sentiment analyser.

Fixes vs. original
-------------------
- Bug #2 : model name corrected to 'deepseek-chat' (not 'deepseek-llm')
- Bug #8 : sliding-window token tracker replaces a simple counter that
           never accounted for the actual per-minute window
- Bug #13: credentials via Settings, not CONFIG dict
- Retry session shared with FactSet module pattern
- Return type guaranteed to always be Tuple[str, str] (bug #10)
"""
from __future__ import annotations

import collections
import logging
import time
from typing import Tuple

import requests

from trader.config import Settings
from trader.data.factset import _retry_session

logger = logging.getLogger(__name__)

# Validated sentiment values
_VALID = frozenset({"YES", "NO", "UNKNOWN"})

Sentiment = str   # Literal["YES", "NO", "UNKNOWN"]


class DeepSeekAnalyzer:
    """
    LLM-powered sentiment analyser backed by the DeepSeek Chat API.

    Rate limiting
    -------------
    Uses a sliding-window deque to count tokens consumed in the last 60 s.
    If adding the next request would exceed the per-minute token budget,
    the call sleeps until enough of the window has expired.

    Parameters
    ----------
    settings : Settings
    """

    _PROMPT_TEMPLATE = (
        "Answer 'YES' if this headline is good for the stock price of {company} "
        "in the {term} term, 'NO' if bad, or 'UNKNOWN' if uncertain — "
        "write that single word on the first line, then one short sentence "
        "of explanation on the second line.\n\n"
        "Headline: {headline}"
    )

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._session  = _retry_session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {settings.deepseek_api_key}",
                "Content-Type":  "application/json",
            }
        )
        # Bug #8 fix: sliding window of (timestamp, tokens) pairs
        self._window: collections.deque[tuple[float, int]] = collections.deque()
        self._window_secs = 60
        self._token_budget = settings.deepseek_tokens_per_minute

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def analyze_sentiment(
        self,
        headline: str,
        company:  str,
        term:     str = "short",
    ) -> Tuple[Sentiment, str]:
        """
        Classify a headline as bullish (YES), bearish (NO), or ambiguous (UNKNOWN).

        Always returns a 2-tuple (sentiment, explanation) — never raises.

        Parameters
        ----------
        headline : news headline text
        company  : company name (used in the prompt)
        term     : investment horizon label ("short" or "long")
        """
        prompt = self._PROMPT_TEMPLATE.format(
            headline=headline, company=company, term=term
        )

        # Estimate token cost conservatively before calling
        estimated_tokens = len(prompt.split()) * 2 + 50
        self._enforce_rate_limit(estimated_tokens)

        try:
            response = self._session.post(
                self._settings.deepseek_base_url,
                json={
                    # Bug #2 fix: correct model identifier
                    "model":       "deepseek-chat",
                    "messages":    [{"role": "user", "content": prompt}],
                    "temperature": 0.1,
                    "max_tokens":  120,
                },
                timeout=30,
            )
            response.raise_for_status()
        except requests.HTTPError as exc:
            logger.error("DeepSeek HTTP error: %s", exc)
            return "UNKNOWN", f"API HTTP error: {exc}"
        except requests.RequestException as exc:
            logger.error("DeepSeek request failed: %s", exc)
            return "UNKNOWN", f"Request failed: {exc}"

        body = response.json()
        actual_tokens = body.get("usage", {}).get("total_tokens", estimated_tokens)
        self._record_tokens(actual_tokens)

        content = body["choices"][0]["message"]["content"].strip()
        lines   = [ln.strip() for ln in content.split("\n") if ln.strip()]

        raw_sentiment = lines[0].upper() if lines else "UNKNOWN"
        explanation   = lines[1] if len(lines) > 1 else "No explanation provided."

        # Validate
        if raw_sentiment not in _VALID:
            logger.warning("Unexpected LLM output: %r — defaulting to UNKNOWN", raw_sentiment)
            return "UNKNOWN", explanation

        return raw_sentiment, explanation  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Rate-limit helpers
    # ------------------------------------------------------------------

    def _purge_old(self) -> None:
        """Remove window entries older than window_secs."""
        cutoff = time.monotonic() - self._window_secs
        while self._window and self._window[0][0] < cutoff:
            self._window.popleft()

    def _tokens_in_window(self) -> int:
        self._purge_old()
        return sum(t for _, t in self._window)

    def _enforce_rate_limit(self, estimated_tokens: int) -> None:
        """Sleep until there is budget for estimated_tokens in the window."""
        while True:
            self._purge_old()
            used = self._tokens_in_window()
            if used + estimated_tokens <= self._token_budget:
                break
            # Wait until the oldest entry expires
            if self._window:
                sleep_until = self._window[0][0] + self._window_secs
                wait = sleep_until - time.monotonic()
                if wait > 0:
                    logger.info(
                        "Token budget reached (%d/%d) — sleeping %.1f s",
                        used, self._token_budget, wait,
                    )
                    time.sleep(wait)
            else:
                break

    def _record_tokens(self, n_tokens: int) -> None:
        self._window.append((time.monotonic(), n_tokens))
