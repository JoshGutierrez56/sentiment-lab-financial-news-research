"""
signals.py
==========
Convert LLM sentiment labels into trading signals.

Keeps HOLD rows in the output (as HOLD action) rather than silently
dropping them — callers decide how to filter.
"""
from __future__ import annotations

import pandas as pd


class TradingStrategy:
    """
    Map sentiment labels → directional trading signals.

    Signal map
    ----------
    YES     → LONG   (bullish)
    NO      → SHORT  (bearish)
    UNKNOWN → HOLD   (no edge)
    """

    SIGNAL_MAP = {"YES": "LONG", "NO": "SHORT", "UNKNOWN": "HOLD"}

    @staticmethod
    def generate_signals(df: pd.DataFrame) -> pd.DataFrame:
        """
        Annotate a news DataFrame with an 'action' column.

        Parameters
        ----------
        df : pd.DataFrame
            Must contain a 'sentiment' column with values YES / NO / UNKNOWN.

        Returns
        -------
        pd.DataFrame
            Same rows as input, with an added 'action' column.
            Call .query("action != 'HOLD'") downstream if you want to filter.
        """
        if "sentiment" not in df.columns:
            raise ValueError("DataFrame must contain a 'sentiment' column.")

        result = df.copy()
        result["action"] = result["sentiment"].map(
            TradingStrategy.SIGNAL_MAP
        ).fillna("HOLD")
        return result

    @staticmethod
    def actionable(df: pd.DataFrame) -> pd.DataFrame:
        """Return only LONG / SHORT rows (convenience filter)."""
        return df[df["action"] != "HOLD"].copy()
