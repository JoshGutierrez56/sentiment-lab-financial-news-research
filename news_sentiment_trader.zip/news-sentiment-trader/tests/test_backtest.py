"""
tests/test_backtest.py
======================
Unit tests for the backtesting engine — focuses on the three metric bugs.
"""
import numpy as np
import pandas as pd
import pytest

from trader.backtest.engine import Backtester


# ── Fixtures ──────────────────────────────────────────────────────────

@pytest.fixture
def price_data() -> pd.DataFrame:
    """Simple price table: 10 trading days, two tickers."""
    rows = []
    for i in range(10):
        date = pd.Timestamp("2022-01-03") + pd.Timedelta(days=i)
        rows.append({"date": date, "ticker": "AAPL", "return": 0.01 * (i % 3 - 1)})
        rows.append({"date": date, "ticker": "MSFT", "return": -0.005})
    return pd.DataFrame(rows)


@pytest.fixture
def backtester(price_data) -> Backtester:
    return Backtester(price_data)


@pytest.fixture
def results_df() -> pd.DataFrame:
    """Hand-crafted results with known metric values."""
    dates = pd.date_range("2022-01-03", periods=6, freq="B", tz="America/New_York")
    returns = [0.02, -0.01, 0.03, -0.02, 0.01, 0.015]
    return pd.DataFrame(
        {
            "timestamp":    dates,
            "ticker":       "AAPL",
            "headline":     "test",
            "sentiment":    "YES",
            "action":       "LONG",
            "trade_return": returns,
        }
    )


# ── Metric tests ──────────────────────────────────────────────────────

def test_max_drawdown_is_non_positive(results_df):
    """Bug #3 fix: max_drawdown must be ≤ 0."""
    metrics = Backtester.calculate_metrics(results_df)
    assert metrics["max_drawdown"] <= 0, (
        f"max_drawdown should be ≤ 0, got {metrics['max_drawdown']}"
    )


def test_max_drawdown_known_value():
    """
    Manually construct a sequence with a known drawdown.
    Returns: +10%, −20%, +5% → NAV: 1.10, 0.88, 0.924
    Peak before trough: 1.10 → drawdown = 0.88/1.10 - 1 = -0.2
    """
    dates = pd.date_range("2022-01-03", periods=3, freq="B", tz="America/New_York")
    df = pd.DataFrame(
        {
            "timestamp":    dates,
            "ticker":       "TEST",
            "headline":     "h",
            "sentiment":    "YES",
            "action":       "LONG",
            "trade_return": [0.10, -0.20, 0.05],
        }
    )
    metrics = Backtester.calculate_metrics(df)
    assert abs(metrics["max_drawdown"] - (-0.20)) < 0.001, (
        f"Expected MDD ≈ -0.20, got {metrics['max_drawdown']}"
    )


def test_total_return_geometric(results_df):
    """Bug #5 fix: total_return uses (1+r).prod()-1, not sum()."""
    r = results_df["trade_return"].values
    expected = float((1 + pd.Series(r)).prod() - 1)
    metrics  = Backtester.calculate_metrics(results_df)
    assert abs(metrics["total_return"] - expected) < 1e-9


def test_sharpe_is_finite(results_df):
    """Bug #4: Sharpe should be finite when std > 0."""
    metrics = Backtester.calculate_metrics(results_df)
    assert np.isfinite(metrics["sharpe_ratio"])


def test_hit_rate_bounds(results_df):
    metrics = Backtester.calculate_metrics(results_df)
    assert 0.0 <= metrics["hit_rate"] <= 1.0


def test_empty_results_returns_empty_dict():
    empty = pd.DataFrame(columns=["timestamp", "ticker", "headline",
                                   "sentiment", "action", "trade_return"])
    assert Backtester.calculate_metrics(empty) == {}


def test_backtest_skips_missing_prices(backtester):
    """Signals with no matching price row should be skipped, not raise."""
    signals = pd.DataFrame(
        [
            {
                "timestamp": pd.Timestamp("2022-01-03 10:00:00-0500"),
                "ticker":    "AAPL",
                "headline":  "Apple beats earnings",
                "sentiment": "YES",
                "action":    "LONG",
            },
            {
                "timestamp": pd.Timestamp("2022-01-03 10:00:00-0500"),
                "ticker":    "NONEXISTENT",
                "headline":  "Phantom company news",
                "sentiment": "YES",
                "action":    "LONG",
            },
        ]
    )
    results = backtester.run_backtest(signals)
    tickers = results["ticker"].tolist()
    assert "NONEXISTENT" not in tickers
