"""
tests/test_sentiment.py
=======================
Unit tests for DeepSeekAnalyzer — all API calls are mocked.
"""
from unittest.mock import MagicMock, patch

import pytest

from trader.config import Settings


@pytest.fixture
def mock_settings() -> Settings:
    """Settings with dummy keys — never hits real APIs."""
    return Settings(
        factset_api_key="test-factset-key",
        factset_base_url="https://api.factset.com/rtnews",
        deepseek_api_key="test-deepseek-key",
        deepseek_base_url="https://api.deepseek.com/v1/chat/completions",
    )


def _make_mock_response(content: str, tokens: int = 50) -> MagicMock:
    mock = MagicMock()
    mock.json.return_value = {
        "choices": [{"message": {"content": content}}],
        "usage":   {"total_tokens": tokens},
    }
    mock.raise_for_status = MagicMock()
    return mock


class TestDeepSeekAnalyzer:

    def test_yes_sentiment(self, mock_settings):
        from trader.nlp.sentiment import DeepSeekAnalyzer

        analyzer = DeepSeekAnalyzer(mock_settings)
        with patch.object(analyzer._session, "post",
                          return_value=_make_mock_response("YES\nStrong product launch.")) as mock_post:
            sentiment, explanation = analyzer.analyze_sentiment(
                "Apple beats earnings by 20%", "Apple", "short"
            )

        assert sentiment == "YES"
        assert "Strong" in explanation
        mock_post.assert_called_once()

    def test_no_sentiment(self, mock_settings):
        from trader.nlp.sentiment import DeepSeekAnalyzer

        analyzer = DeepSeekAnalyzer(mock_settings)
        with patch.object(analyzer._session, "post",
                          return_value=_make_mock_response("NO\nMajor revenue miss.")):
            sentiment, explanation = analyzer.analyze_sentiment(
                "Apple misses revenue by 15%", "Apple"
            )

        assert sentiment == "NO"

    def test_unknown_sentiment(self, mock_settings):
        from trader.nlp.sentiment import DeepSeekAnalyzer

        analyzer = DeepSeekAnalyzer(mock_settings)
        with patch.object(analyzer._session, "post",
                          return_value=_make_mock_response("UNKNOWN\nAmbiguous news.")):
            sentiment, _ = analyzer.analyze_sentiment("Apple holds annual AGM", "Apple")

        assert sentiment == "UNKNOWN"

    def test_invalid_llm_output_defaults_to_unknown(self, mock_settings):
        """Bug #10 fix: invalid LLM output must not crash — returns UNKNOWN."""
        from trader.nlp.sentiment import DeepSeekAnalyzer

        analyzer = DeepSeekAnalyzer(mock_settings)
        with patch.object(analyzer._session, "post",
                          return_value=_make_mock_response("MAYBE\nNot sure.")):
            sentiment, _ = analyzer.analyze_sentiment("Some headline", "Acme")

        assert sentiment == "UNKNOWN"

    def test_http_error_returns_unknown(self, mock_settings):
        """Network failures must return UNKNOWN, not raise."""
        import requests
        from trader.nlp.sentiment import DeepSeekAnalyzer

        analyzer = DeepSeekAnalyzer(mock_settings)
        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = requests.HTTPError("503")

        with patch.object(analyzer._session, "post", return_value=mock_response):
            sentiment, explanation = analyzer.analyze_sentiment("News headline", "Corp")

        assert sentiment == "UNKNOWN"
        assert "503" in explanation

    def test_uses_correct_model_name(self, mock_settings):
        """Bug #2 fix: must use 'deepseek-chat', not 'deepseek-llm'."""
        from trader.nlp.sentiment import DeepSeekAnalyzer

        analyzer = DeepSeekAnalyzer(mock_settings)
        with patch.object(analyzer._session, "post",
                          return_value=_make_mock_response("YES\nGood.")) as mock_post:
            analyzer.analyze_sentiment("Good headline", "Corp")

        call_json = mock_post.call_args.kwargs.get("json") or mock_post.call_args.args[0]
        if not call_json:
            call_json = mock_post.call_args[1].get("json", {})
        assert call_json.get("model") == "deepseek-chat", (
            f"Expected 'deepseek-chat', got '{call_json.get('model')}'"
        )
