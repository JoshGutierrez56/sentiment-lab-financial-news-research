"""
tests/test_strategy.py
======================
Unit tests for signal generation — no API calls needed.
Bug #6 fix: pytest fixtures live here, not in the main module.
"""
import pandas as pd
import pytest

from trader.strategy.signals import TradingStrategy


@pytest.fixture
def sample_news() -> pd.DataFrame:
    """Minimal news DataFrame covering all three sentiment labels."""
    return pd.DataFrame(
        [
            {
                "timestamp": pd.Timestamp("2022-01-03 09:30:00-0500"),
                "ticker":    "AAPL",
                "headline":  "Apple launches revolutionary new product",
                "sentiment": "YES",
            },
            {
                "timestamp": pd.Timestamp("2022-01-04 10:00:00-0500"),
                "ticker":    "MSFT",
                "headline":  "Microsoft misses earnings estimates badly",
                "sentiment": "NO",
            },
            {
                "timestamp": pd.Timestamp("2022-01-05 14:00:00-0500"),
                "ticker":    "GOOGL",
                "headline":  "Alphabet announces routine board meeting",
                "sentiment": "UNKNOWN",
            },
        ]
    )


def test_yes_maps_to_long(sample_news):
    result = TradingStrategy.generate_signals(sample_news)
    aapl = result[result["ticker"] == "AAPL"]
    assert aapl.iloc[0]["action"] == "LONG"


def test_no_maps_to_short(sample_news):
    result = TradingStrategy.generate_signals(sample_news)
    msft = result[result["ticker"] == "MSFT"]
    assert msft.iloc[0]["action"] == "SHORT"


def test_unknown_maps_to_hold(sample_news):
    result = TradingStrategy.generate_signals(sample_news)
    googl = result[result["ticker"] == "GOOGL"]
    assert googl.iloc[0]["action"] == "HOLD"


def test_generate_signals_preserves_all_rows(sample_news):
    """generate_signals must NOT drop HOLD rows — callers filter."""
    result = TradingStrategy.generate_signals(sample_news)
    assert len(result) == len(sample_news)


def test_actionable_filters_hold(sample_news):
    signals = TradingStrategy.generate_signals(sample_news)
    actionable = TradingStrategy.actionable(signals)
    assert "HOLD" not in actionable["action"].values
    assert len(actionable) == 2


def test_missing_sentiment_column_raises():
    bad_df = pd.DataFrame({"ticker": ["AAPL"], "headline": ["test"]})
    with pytest.raises(ValueError, match="sentiment"):
        TradingStrategy.generate_signals(bad_df)
